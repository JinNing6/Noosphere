# entropy-calculus

This namespace is automatically reserved for the Noosphere / GOOOD Network ecosystem as a structural dependency.
